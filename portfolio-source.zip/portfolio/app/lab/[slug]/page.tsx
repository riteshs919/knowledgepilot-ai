import {notFound} from 'next/navigation';
import ProjectLab from '@/components/project-lab';
const slugs=['vendor-support-automation','marketing-intelligence','forecasting-optimization'];
export function generateStaticParams(){return slugs.map(slug=>({slug}))}
export const metadata={title:'Interactive project workbench'};
export default async function Page({params}:{params:Promise<{slug:string}>}){const {slug}=await params;if(!slugs.includes(slug))notFound();return <ProjectLab slug={slug}/>}
