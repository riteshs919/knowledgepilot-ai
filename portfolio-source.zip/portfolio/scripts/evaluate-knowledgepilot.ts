import fs from "node:fs";import path from "node:path";import {performance} from "node:perf_hooks";import {answerQuery,type Role,documents,chunkDocument} from "../lib/knowledgepilot";
const cases:[string,Role,string|null][]=[
["When are expense claims due?","support","expenses"],
["Who approves expense claims above $500?","operations","expenses"],
["How is new account access approved?","support","access"],
["When does emergency account access expire?","operations","access"],
["How are vendor bank-detail changes verified?","support","vendor"],
["What documents are required for vendor onboarding?","operations","onboarding"],
["What is the vendor onboarding timeline?","support","onboarding"],
["How often are priority-one incident updates posted?","support","incident"],
["Who approves product release notes?","operations","release"],
["How long are customer inquiry records retained?","support","retention"],
["When does operations rota planning close?","operations","operations-rota"],
["What is the lunar expedition launch date?","support",null],
["What is the maximum submarine pressure tolerance?","operations",null],
["When does operations rota planning close?","support",null]
];
const results=cases.map(([query,role,expected])=>{const start=performance.now();const actual=answerQuery(query,role);const latency=performance.now()-start;return {query,role,expected,topSource:actual.passages[0]?.sourceId||null,returnedSources:actual.passages.map(x=>x.sourceId),refused:actual.refused,latencyMs:latency,pass:expected?actual.passages[0]?.sourceId===expected:actual.refused}});
const supported=results.filter(r=>r.expected);const refused=results.filter(r=>!r.expected);const report={generatedAt:new Date().toISOString(),dataset:"14 hand-authored synthetic queries, not an independent holdout",documents:documents.length,chunks:documents.flatMap(chunkDocument).length,retrieval:"TF-IDF cosine, access filter before vectorization, score>=0.12 and query coverage>=0.4",top1Hits:supported.filter(r=>r.pass).length,supportedQueries:supported.length,refusalPasses:refused.filter(r=>r.pass).length,refusalQueries:refused.length,accessViolations:results.reduce((sum,r)=>sum+r.returnedSources.filter(id=>!documents.find(d=>d.id===id)?.roles.includes(r.role)).length,0),results};
const out=path.resolve("../../apps/knowledgepilot/evaluation.json");fs.writeFileSync(out,JSON.stringify(report,null,2));console.log(JSON.stringify({top1:`${report.top1Hits}/${report.supportedQueries}`,refusal:`${report.refusalPasses}/${report.refusalQueries}`,accessViolations:report.accessViolations},null,2));if(results.some(r=>!r.pass))process.exitCode=1;
