"use client";
import {motion,useReducedMotion} from "motion/react";
export function Reveal({children}:{children:React.ReactNode}){const reduce=useReducedMotion();return <motion.div initial={reduce?false:{opacity:1,y:14}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:0.4}}>{children}</motion.div>}
