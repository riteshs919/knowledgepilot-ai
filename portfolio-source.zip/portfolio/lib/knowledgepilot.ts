import rawDocuments from "@/content/knowledgepilot.json";
export type Role="operations"|"support";
export type Document={id:string;title:string;roles:string[];text:string;provenance:string};
export type Passage={sourceId:string;title:string;chunkId:string;text:string;score:number};
export const documents:Document[]=rawDocuments;
const stop=new Set("a an the is are was were be been to of for and or in on at by from with as how what when who which do does can i we you it this that must should please me tell about my our within".split(" "));
export function tokens(text:string){return text.toLowerCase().match(/[a-z0-9]+/g)?.filter(t=>!stop.has(t))||[]}
export function chunkDocument(doc:Document){return doc.text.split(/\n\n+/).filter(Boolean).flatMap((paragraph,index)=>{const words=paragraph.split(/\s+/);const parts=[];for(let start=0;start<words.length;start+=100)parts.push({sourceId:doc.id,title:doc.title,chunkId:`${doc.id}:${index}:${start}`,text:words.slice(start,start+120).join(" ")});return parts;});}
export function retrieve(query:string,role:Role,source:Document[]=documents):Passage[]{
 const chunks=source.filter(d=>d.roles.includes(role)).flatMap(chunkDocument);const qt=tokens(query);if(!qt.length)return [];
 const df=new Map<string,number>();const terms=chunks.map(c=>tokens(c.text));for(const t of terms)for(const word of new Set(t))df.set(word,(df.get(word)||0)+1);
 const idf=(t:string)=>Math.log((chunks.length+1)/((df.get(t)||0)+1))+1;
 function vector(ts:string[]){const counts=new Map<string,number>();for(const t of ts)counts.set(t,(counts.get(t)||0)+1);return new Map([...counts].map(([t,n])=>[t,(1+Math.log(n))*idf(t)]));}
 const qv=vector(qt);const norm=(v:Map<string,number>)=>Math.sqrt([...v.values()].reduce((sum,x)=>sum+x*x,0));const qn=norm(qv);
 return chunks.map((chunk,i)=>{const v=vector(terms[i]);const vn=norm(v);const dot=[...qv].reduce((sum,[t,x])=>sum+x*(v.get(t)||0),0);const coverage=new Set(qt.filter(t=>v.has(t))).size/new Set(qt).size;return {...chunk,score:dot/(qn*vn||1),coverage};}).filter(c=>c.score>=0.12&&c.coverage>=0.4).sort((a,b)=>b.score-a.score).slice(0,3).map(({coverage,...c})=>{void coverage;return c;});
}
export function answerQuery(query:string,role:Role){const passages=retrieve(query,role);return {refused:passages.length===0,mode:"extractive" as const,answer:passages.length?"The following passages match your question. Review the source policy before acting.":"I couldn’t find enough supporting information in the documents available to this role.",passages};}
