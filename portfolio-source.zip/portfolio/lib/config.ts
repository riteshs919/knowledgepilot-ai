import profile from "@/content/profile.json";
export {profile};
export const siteUrl=process.env.NEXT_PUBLIC_SITE_URL || process.env.RENDER_EXTERNAL_URL || "http://localhost:3000";
export const contactReady=Boolean(process.env.RESEND_API_KEY && process.env.CONTACT_TO_EMAIL && process.env.CONTACT_FROM_EMAIL && process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN && process.env.RATE_LIMIT_SALT);
export function safeUrl(value: string | null | undefined){if(!value)return null;try{const url=new URL(value);return url.protocol==="https:"?url.href:null;}catch{return null;}}
export const calendar=safeUrl(process.env.NEXT_PUBLIC_CALENDAR_URL || profile.calendar);
export const github=safeUrl(process.env.NEXT_PUBLIC_GITHUB_URL || profile.github);
