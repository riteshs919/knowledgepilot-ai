"use client";
export function trackEvent(name:string,properties:Record<string,string>={}){if(process.env.NEXT_PUBLIC_ANALYTICS_EVENTS_ENABLED!=="true")return;const tracker=(window as Window & {umami?:{track:(name:string,data:Record<string,string>)=>void}}).umami;tracker?.track(name,properties);}
