"""Real browser UI backed by actual ASGI API and SQLite, without listening sockets.
Route interception transports requests to TestClient; no responses are mocked.
"""
import os,sys,json,selectors,time,traceback,secrets,atexit,httpx
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
original=selectors.EpollSelector.select
def poll(self,timeout=None):return original(self,min(timeout,.02) if timeout is not None else .02)
selectors.EpollSelector.select=poll
from fastapi.testclient import TestClient
from backend.api import app,limits
from playwright.sync_api import sync_playwright,expect
from backend.db import connect
from backend.auth.security import hash_password
OUT=ROOT/'apps/portfolio/screenshots';OUT.mkdir(exist_ok=True)
password=os.getenv('KP_BROWSER_PASSWORD') or secrets.token_urlsafe(24)
with connect() as c:
    ids={x[0] for x in c.execute('SELECT id FROM documents')}
    expected={m['id'] for m in json.loads((ROOT/'datasets/synthetic_company/manifest.json').read_text())}
    if ids!=expected:raise SystemExit('Browser workflows require an isolated, freshly bootstrapped synthetic corpus.')
    prior=c.execute('SELECT password FROM users WHERE email=?',('admin@northstar.demo',)).fetchone()[0]
    c.execute('UPDATE users SET password=? WHERE email=?',(hash_password(password),'admin@northstar.demo'))
def restore_password():
    with connect() as c:c.execute('UPDATE users SET password=? WHERE email=?',(prior,'admin@northstar.demo'))
atexit.register(restore_password)
limits.clear();checks=[]
with TestClient(app) as client, sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.getenv('KP_CHROMIUM_PATH') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-crashpad-for-testing','--disable-crash-reporter','--no-zygote','--single-process','--disable-gpu'])
    context=browser.new_context(viewport={'width':1440,'height':1000})
    def transport(route):
        req=route.request
        from urllib.parse import urlsplit
        url=urlsplit(req.url);path=url.path+('?' + url.query if url.query else '')
        if url.hostname not in ('knowledgepilot.test','127.0.0.1','localhost'):route.abort();return
        gateway=httpx.Client(trust_env=False,timeout=150) if os.getenv('KP_E2E_BASE_URL') else client
        destination=os.environ['KP_E2E_BASE_URL']+path if os.getenv('KP_E2E_BASE_URL') else path
        response=gateway.request(req.method,destination,content=req.post_data_buffer,headers={k:v for k,v in req.all_headers().items() if k.lower() not in ('host','content-length','connection')})
        headers=dict(response.headers);headers.pop('content-length',None)
        route.fulfill(status=response.status_code,headers=headers,body=response.content)
    base_url=os.getenv('KP_E2E_BASE_URL','http://knowledgepilot.test')
    context.route('**/*',transport)
    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(base_url+'/');page.get_by_label('Work email').fill('admin@northstar.demo');page.get_by_label('Password',exact=True).fill(password);page.screenshot(path=str(OUT/'login.png'),full_page=True)
    page.get_by_role('button',name='Sign in to workspace').click();page.get_by_role('heading',name='Ask your company knowledge').wait_for();checks.append('login')
    page.get_by_label('Your question',exact=True).fill('How many annual leave days do employees receive?');page.get_by_role('button',name='Ask KnowledgePilot').click();page.locator('.message.assistant').wait_for();assert '24 paid annual leave' in page.locator('.message.assistant').inner_text();assert page.locator('.source-card').count()>0;checks.append('retrieval answer and citations');page.screenshot(path=str(OUT/'workspace.png'),full_page=True)
    page.get_by_role('button',name='Helpful answer',exact=True).click();page.locator('#toast').filter(has_text='Feedback recorded').wait_for();checks.append('feedback')
    page.get_by_role('button',name='Document library',exact=False).click();page.get_by_role('heading',name='Document library',exact=True).wait_for();assert page.locator('.doc-card').count()>=40;page.screenshot(path=str(OUT/'library.png'),full_page=True);checks.append('document library')
    page.get_by_role('button',name='Preview',exact=True).first.click();page.locator('dialog').wait_for();assert len(page.locator('.preview').inner_text())>100;page.get_by_role('button',name='Close dialog').click();checks.append('preview')
    page.get_by_role('button',name='Upload document').click();page.locator('#upload-file').set_input_files({'name':'browser-policy.md','mimeType':'text/markdown','buffer':b'# Browser policy\nBrowser test office policy: request desk booking two days before arrival. Unique workflow test.'});page.get_by_label('Title',exact=True).fill('Browser policy test');page.get_by_role('button',name='Upload and index').click();page.get_by_text('Document uploaded.',exact=False).wait_for();page.get_by_label('Search documents').fill('Browser policy test');page.get_by_role('button',name='Refresh status').click();expect(page.locator('#doc-search')).to_have_value('');page.get_by_label('Search documents').fill('Browser policy test');expect(page.locator('.doc-card')).to_have_count(1);checks.append('upload workflow')
    page.once('dialog',lambda d:d.accept());page.get_by_role('button',name='Delete family').click();expect(page.locator('#doc-search')).to_have_value('');page.get_by_label('Search documents').fill('Browser policy test');expect(page.locator('.doc-card')).to_have_count(0);checks.append('delete workflow')
    page.get_by_role('button',name='Overview',exact=False).click();page.get_by_role('heading',name='Workspace overview').wait_for();page.screenshot(path=str(OUT/'admin.png'),full_page=True);checks.append('actual dashboard metrics')
    page.get_by_role('button',name='Settings',exact=False).click();page.get_by_role('heading',name='Settings & administration').wait_for();page.get_by_role('button',name='Save configuration').click();page.get_by_text('Configuration saved.',exact=True).wait_for();checks.append('settings save')
    page.get_by_role('button',name='Ask knowledge',exact=False).click();page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(OUT/'mobile.png'),full_page=True);assert page.evaluate('document.documentElement.scrollWidth <= innerWidth');checks.append('responsive width')
    page.set_viewport_size({'width':1440,'height':1000});page.goto(base_url+'/portfolio');page.get_by_role('heading',name='I Build AI Systems That Solve Real Business Problems.').wait_for();page.screenshot(path=str(OUT/'portfolio.png'),full_page=True);checks.append('portfolio')
    browser.close();assert not errors,errors
    for screenshot in OUT.glob('*.png'):screenshot.chmod(0o644)
(ROOT/'docs/technical/browser-test-results.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'javascript_errors':errors,'transport':'Playwright Chromium using a real HTTP request gateway to the running Uvicorn server' if os.getenv('KP_E2E_BASE_URL') else 'Playwright Chromium with real ASGI route transport; no mocked responses'},indent=2))
print(json.dumps({'passed':len(checks),'checks':checks},indent=2))
