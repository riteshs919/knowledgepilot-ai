from backend.api import Question
from backend.generation.engine import answer

def test_short_greeting_is_accepted_and_helpful():
    q=Question(question="hi")
    text,sources,supported=answer(q.question,[],{"mode":"hosted"})
    assert "Hello!" in text and "annual leave" in text
    assert sources == [] and supported is False
