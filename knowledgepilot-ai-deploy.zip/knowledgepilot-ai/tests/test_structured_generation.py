import unittest,json
from unittest.mock import patch
import httpx
from backend.generation.engine import OllamaLanguageModel,validate_citations
class StructuredGenerationTests(unittest.TestCase):
    def response(self,content):return httpx.Response(200,json={'message':{'content':json.dumps(content)}},request=httpx.Request('POST','http://localhost/api/chat'))
    def test_model_selected_citations_rendered(self):
        with patch('backend.generation.engine.httpx.Client') as client:
            client.return_value.__enter__.return_value.post.return_value=self.response({'supported':True,'claims':[{'text':'Leave is 24 days.','sources':[1]}]})
            result=OllamaLanguageModel().generate('leave',[{'title':'Leave','version':2,'page':None,'text':'Leave is 24 days.'}],'test')
            self.assertEqual(result,'Leave is 24 days. [S1]');self.assertTrue(validate_citations(result,[{}]))
    def test_invalid_model_citation_refused(self):
        with patch('backend.generation.engine.httpx.Client') as client:
            client.return_value.__enter__.return_value.post.return_value=self.response({'supported':True,'claims':[{'text':'Leave','sources':[99]}]})
            self.assertEqual(OllamaLanguageModel().generate('leave',[{'title':'Leave','version':2,'page':None,'text':'Leave.'}],'test'),'UNSUPPORTED')

    def test_unknown_model_result_remains_unsupported(self):
        with patch('backend.generation.engine.httpx.Client') as client:
            client.return_value.__enter__.return_value.post.return_value=self.response({'supported':False,'claims':[]})
            self.assertEqual(OllamaLanguageModel().generate('unknown',[{'title':'Leave','version':2,'page':None,'text':'Leave.'}],'test'),'UNSUPPORTED')
