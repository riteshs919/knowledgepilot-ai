import unittest,sys,uuid,json,time,io
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from backend.db import connect,init
from backend.auth.security import hash_password
from backend.retrieval.search import search
class BoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from backend.api import app,limits
        limits.clear();init();cls.client=TestClient(app);cls.client.__enter__();cls.ids=[]
        cls.password='Boundary-testing-2026!'
        for name,role,groups in [('employee','employee',['employees']),('admin','admin',['employees'])]:
            uid=uuid.uuid4().hex;cls.ids.append(uid)
            with connect() as c:c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,1)',(uid,uid+'@example.test',name,hash_password(cls.password),role,json.dumps(groups)))
    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None,None,None)
        with connect() as c:
            for uid in cls.ids:
                c.execute('DELETE FROM sessions WHERE user_id=?',(uid,));c.execute('DELETE FROM conversations WHERE user_id=?',(uid,));c.execute('DELETE FROM feedback WHERE user_id=?',(uid,));c.execute('DELETE FROM queries WHERE user_id=?',(uid,));c.execute('DELETE FROM users WHERE id=?',(uid,))
    def as_user(self,index):
        self.client.cookies.clear();r=self.client.post('/api/auth/login',json={'email':self.ids[index]+'@example.test','password':self.password});self.assertEqual(r.status_code,200);return {'X-CSRF-Token':self.client.get('/api/auth/me').json()['csrf']}
    def test_employee_cannot_admin_upload_or_preview_restricted(self):
        h=self.as_user(0)
        self.assertEqual(self.client.get('/api/admin/metrics').status_code,403)
        self.assertEqual(self.client.get('/api/admin/users').status_code,403)
        self.assertEqual(self.client.get('/api/documents/NS-030').status_code,404)
        self.assertEqual(self.client.get('/api/documents/NS-030/download').status_code,404)
        self.assertEqual(self.client.post('/api/documents',headers=h,files={'file':('a.txt',b'Test upload')}).status_code,403)
        self.assertEqual(self.client.delete('/api/documents/NS-001',headers=h).status_code,403)
        self.assertEqual(self.client.post('/api/search',headers=h,json={'question':'security key custody checkout requirements'}).json()['sources'],[])
    def test_conversation_ownership_and_feedback(self):
        h=self.as_user(1);r=self.client.post('/api/chat',headers=h,json={'question':'annual leave days'});self.assertEqual(r.status_code,200);data=r.json()
        h=self.as_user(0);self.assertEqual(self.client.get('/api/conversations/'+data['conversation_id']).status_code,404)
        self.assertEqual(self.client.post('/api/feedback/'+data['id'],headers=h,json={'rating':1}).status_code,404)
        self.assertEqual(self.client.post('/api/chat',headers=h,json={'question':'follow up','conversation_id':data['conversation_id']}).status_code,404)
    def test_history_revocation(self):
        h=self.as_user(0);r=self.client.post('/api/chat',headers=h,json={'question':'annual leave days'});self.assertEqual(r.status_code,200);data=r.json()
        doc=data['sources'][0]['doc_id']
        with connect() as c:
            saved=c.execute('SELECT groups_json FROM documents WHERE id=?',(doc,)).fetchone()[0]
            c.execute('UPDATE documents SET groups_json=? WHERE id=?',('["restricted-test"]',doc))
        try:
            history=self.client.get('/api/conversations/'+data['conversation_id']).json();assistant=history[-1];self.assertEqual(assistant['sources'],[]);self.assertIn('source access has changed',assistant['body'])
        finally:
            with connect() as c:c.execute('UPDATE documents SET groups_json=? WHERE id=?',(saved,doc))
    def test_corruption_and_metadata_validation(self):
        h=self.as_user(1);r=self.client.post('/api/documents',headers=h,data={'metadata':'[]'},files={'file':('a.txt',b'a')});self.assertEqual(r.status_code,422)
        r=self.client.post('/api/documents',headers=h,files={'file':('bad.pdf',uuid.uuid4().hex.encode())});self.assertEqual(r.status_code,202);doc=r.json()['id']
        try:
            for _ in range(100):
                d=self.client.get('/api/documents/'+doc).json()
                if d['status']=='failed':break
                time.sleep(.02)
            self.assertEqual(d['status'],'failed');self.assertIn('PDF signature',d['error'])
        finally:self.client.delete('/api/documents/'+doc,headers=h)
    def test_request_size_and_security_headers(self):
        r=self.client.post('/api/contact',headers={'Content-Length':str(12*1024*1024)},content=b'{}');self.assertEqual(r.status_code,413)
        r=self.client.get('/');self.assertEqual(r.status_code,200);self.assertEqual(r.headers['x-frame-options'],'DENY');self.assertIn("script-src 'self'",r.headers['content-security-policy'])
    def test_named_user_and_failed_current_version(self):
        from backend.documents.service import upload
        user={'id':self.ids[1],'name':'test','role':'admin','groups':[]};unique=uuid.uuid4().hex
        first=upload('named.md',('# Named\nRestricted named policy '+unique).encode(),{'title':'Named Policy','groups':[],'users':[self.ids[0]]},user)
        try:
            for _ in range(100):
                with connect() as c:d=c.execute('SELECT status FROM documents WHERE id=?',(first,)).fetchone()
                if d[0]=='indexed':break
                time.sleep(.01)
            permitted={'id':self.ids[0],'role':'employee','groups':[]}
            self.assertTrue(search.search('named policy',permitted))
            self.assertEqual(search.search('named policy',{'id':'outsider','role':'employee','groups':[]}),[])
            replacement=upload('named.pdf',b'%PDF-broken-'+unique.encode(),{'title':'Named Policy','groups':[],'users':[self.ids[0]]},user,first)
            self.assertEqual(search.search('named policy',permitted),[])
        finally:
            with connect() as c:
                family=c.execute('SELECT family FROM documents WHERE id=?',(first,)).fetchone()[0];c.execute('DELETE FROM documents WHERE family=?',(family,))
    def test_rate_limit(self):
        from backend.api import limits
        limits.clear()
        for _ in range(10):self.client.post('/api/auth/login',json={'email':'nobody@example.test','password':'wrong'})
        self.assertEqual(self.client.post('/api/auth/login',json={'email':'nobody@example.test','password':'wrong'}).status_code,429);limits.clear()
