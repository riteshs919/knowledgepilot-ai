"""Provider protocol tests use an injected HTTP transport, not claimed model inference."""
import unittest,json
from unittest.mock import patch
import httpx,numpy as np
from backend.retrieval.providers import OllamaEmbedding,CrossEncoderReranker
from backend.generation.engine import OllamaLanguageModel,answer
class ProviderContracts(unittest.TestCase):
    def test_ollama_embedding_payload(self):
        calls=[];real_client=httpx.Client
        def handler(request):
            body=json.loads(request.content);calls.append(body)
            return httpx.Response(200,json={'embeddings':[[1.,0.,0.] for _ in body['input']]})
        def client(**kwargs):return real_client(transport=httpx.MockTransport(handler),**kwargs)
        with patch('backend.retrieval.providers.httpx.Client',side_effect=client):
            e=OllamaEmbedding('nomic-embed-text');v=e.fit(['policy']);q=e.query('question')
        self.assertEqual(v.shape,(1,3));self.assertEqual(calls[0]['input'],['search_document: policy']);self.assertEqual(calls[1]['input'],['search_query: question'])
    def test_generation_prompt_and_invalid_source_rejected(self):
        source={'text':'Annual leave is 24 days.','title':'Leave','version':2,'page':1}
        with patch.object(OllamaLanguageModel,'generate',return_value='Invented text [S99]'):
            text,cited,supported=answer('annual leave',[source],{'mode':'ollama','model':'test','top_k':6});self.assertFalse(supported);self.assertEqual(cited,[])
    def test_reranking_order_contract(self):
        # Actual rank adapter with deterministic injected scorer; neural weights not exercised.
        class Scorer:
            def predict(self,pairs):return np.array([.1,.8])
        reranker=object.__new__(CrossEncoderReranker);reranker.model=Scorer()
        ranked=reranker.rank('query',[{'text':'low'},{'text':'high'}]);self.assertEqual(ranked[0]['text'],'high')
