import os,unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from backend.api import app,limits
class PublicDemoTests(unittest.TestCase):
    def test_disabled_demo_has_no_session(self):
        with patch.dict(os.environ,{'KP_ENABLE_PUBLIC_DEMO':'false'}),TestClient(app) as client:
            limits.clear()
            self.assertEqual(client.post('/api/auth/demo',headers={'origin':'http://localhost:3000'}).status_code,404)
    def test_local_synthetic_demo_is_employee_and_admin_denied(self):
        with patch.dict(os.environ,{'KP_ENABLE_PUBLIC_DEMO':'true'}),TestClient(app) as client:
            limits.clear()
            self.assertEqual(client.post('/api/auth/demo',headers={'origin':'https://evil.example'}).status_code,403)
            self.assertEqual(client.post('/api/auth/demo',headers={'origin':'http://localhost:3000'}).status_code,200)
            user=client.get('/api/auth/me').json()
            self.assertEqual(user['role'],'employee');self.assertEqual(user['groups'],['employees'])
            self.assertEqual(client.get('/api/admin/metrics').status_code,403)
