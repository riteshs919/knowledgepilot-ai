import unittest,json,os
from unittest.mock import patch
import httpx
from backend.generation.engine import HostedLanguageModel
class HostedGenerationTests(unittest.TestCase):
    def test_payload_secret_and_citations(self):
        real=httpx.Client;calls=[]
        def handle(request):
            calls.append(request)
            return httpx.Response(200,json={'choices':[{'message':{'content':json.dumps({'supported':True,'claims':[{'text':'Leave is 24 days.','sources':[1]}]})}}]})
        def client(**kwargs):return real(transport=httpx.MockTransport(handle),**kwargs)
        with patch.dict(os.environ,{'KP_LLM_API_KEY':'test-only','KP_LLM_BASE_URL':'https://api.groq.com/openai/v1'}),patch('backend.generation.engine.httpx.Client',side_effect=client):
            result=HostedLanguageModel().generate('annual leave',[{'title':'Leave','version':2,'page':None,'text':'Leave is 24 days.'}],'openai/gpt-oss-20b')
        self.assertEqual(result,'Leave is 24 days. [S1]')
        self.assertEqual(calls[0].headers['Authorization'],'Bearer test-only')
        self.assertEqual(json.loads(calls[0].content)['response_format'],{'type':'json_object'})
    def test_missing_credentials_and_invalid_citation_fail(self):
        with patch.dict(os.environ,{'KP_LLM_API_KEY':''}):
            with self.assertRaises(httpx.RequestError):HostedLanguageModel().generate('leave',[],'test')
        real=httpx.Client
        def handle(request):return httpx.Response(200,json={'choices':[{'message':{'content':json.dumps({'supported':True,'claims':[{'text':'wrong','sources':[99]}]})}}]})
        with patch.dict(os.environ,{'KP_LLM_API_KEY':'test-only'}),patch('backend.generation.engine.httpx.Client',side_effect=lambda **kw:real(transport=httpx.MockTransport(handle),**kw)):
            self.assertEqual(HostedLanguageModel().generate('leave',[{'title':'Leave','version':2,'page':None,'text':'Leave.'}],'test'),'UNSUPPORTED')
