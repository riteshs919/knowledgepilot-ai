import sys,os,json,time,hashlib,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from backend.db import init,connect
from backend.auth.security import hash_password
from backend.documents.service import enqueue,pool
ROOT=Path(__file__).resolve().parents[1]
def main():
    init();password=os.getenv('KP_BOOTSTRAP_PASSWORD')
    if not password or len(password)<12:raise SystemExit('Set KP_BOOTSTRAP_PASSWORD to a unique password of at least 12 characters. No default credentials are installed.')
    with connect() as c:
        for email,name,role,groups in [('admin@northstar.demo','Alex Morgan','admin',['employees','hr','support','security','engineering','vendor']),('employee@northstar.demo','Taylor Reed','employee',['employees']),('editor@northstar.demo','Jordan Ellis','editor',['employees'])]:
            c.execute('INSERT OR IGNORE INTO users VALUES(?,?,?,?,?,?,1)',(uuid.uuid4().hex,email,name,hash_password(password),role,json.dumps(groups)))
    for m in json.loads((ROOT/'datasets/synthetic_company/manifest.json').read_text()):
        data=(ROOT/'datasets/synthetic_company'/m['file']).read_bytes()
        with connect() as c:
            if c.execute('SELECT 1 FROM documents WHERE id=?',(m['id'],)).fetchone():continue
            c.execute('INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(m['id'],m['family'],m['title'],m['file'],m['category'],m['owner'],m['version'],m['effective'],json.dumps(m['groups']),'[]',hashlib.sha256(data).hexdigest(),'queued',None,data,time.time()))
        enqueue(m['id'])
        # Keep bootstrap bounded, avoid saturating queue.
        while True:
            with connect() as c:status=c.execute('SELECT status FROM documents WHERE id=?',(m['id'],)).fetchone()[0]
            if status in ('indexed','failed'):break
            time.sleep(.02)
    pool.shutdown(wait=True)
    print('Initialized synthetic corpus and three demo accounts. Password comes from KP_BOOTSTRAP_PASSWORD.')
if __name__=='__main__':main()
