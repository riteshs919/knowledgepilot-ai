import sys,json,time,datetime,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from backend.db import init,settings
from backend.retrieval.search import search
from backend.generation.engine import answer,validate_citations
from backend.evaluation.metrics import recall_at_k,extractive_support
ROOT=Path(__file__).resolve().parents[1]
def main():
    init();config=settings();questions=json.loads((ROOT/'datasets/evaluation/questions.json').read_text());rows=[]
    for index,item in enumerate(questions):
        user={'id':'eval','role':'employee','groups':item['groups']};start=time.perf_counter()
        sources=search.search(item['question'],user);text,cited,supported=answer(item['question'],sources,config)
        found={s['doc_id'] for s in sources};expected=set(item['expected_documents'])
        rows.append({**item,'retrieved':sorted(found),'recall':recall_at_k(expected,found),'supported':supported,'citation_valid':validate_citations(text,cited) if supported else None,'extractive_support':extractive_support(text,cited) if supported and config['mode']=='extractive' else None,'unsupported_correct':not supported if item['unsupported'] else None,'latency_seconds':time.perf_counter()-start})
        if (index+1)%10==0:print(f'Evaluated {index+1}/{len(questions)} questions',flush=True)
    def mean(values):
        values=[v for v in values if v is not None];return sum(values)/len(values) if values else None
    restricted=[r for r in rows if r['kind']=='restricted']
    known=[r for r in rows if not r['unsupported']]
    report={'model':config['model'],'embedding_model':config['embedding_model'],'known_queries':len(known),'supported_known_queries':sum(r['supported'] for r in known),'answer_coverage':mean([r['supported'] for r in known]),'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':config['mode'],'questions':len(rows),'top_k':config['top_k'],'recall_at_k':mean([r['recall'] for r in rows]),'citation_validity':mean([r['citation_valid'] for r in rows]),'extractive_support_heuristic':mean([r['extractive_support'] for r in rows]),'unsupported_accuracy':mean([r['unsupported_correct'] for r in rows]),'permission_boundary_accuracy':mean([not any(x in r['retrieved'] for x in ('NS-007','NS-030')) for r in restricted]),'mean_latency_seconds':mean([r['latency_seconds'] for r in rows]),'human_review':False,'limitations':'Synthetic benchmark, templated questions; not representative of real client traffic. Citation validity checks IDs, not entailment. Extractive support checks verbatim inclusion. No generated-answer support assessment in Ollama mode.','results':rows}
    (ROOT/'docs/technical/evaluation-results.json').write_text(json.dumps(report,indent=2))
    (ROOT/'apps/portfolio/evaluation-results.json').write_text(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
if __name__=='__main__':main()
