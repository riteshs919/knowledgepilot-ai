import sys,json,os,httpx
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from backend.db import init,connect
init();url=os.getenv('OLLAMA_URL','http://localhost:11434');model=os.getenv('KP_LLM_MODEL','qwen2.5:7b');embedding='nomic-embed-text'
with httpx.Client(timeout=120,trust_env=False) as c:
    for name in (model,embedding):
        r=c.post(url+'/api/show',json={'model':name});r.raise_for_status()
    r=c.post(url+'/api/embed',json={'model':embedding,'input':['search_query: annual leave']});r.raise_for_status()
    r=c.post(url+'/api/chat',json={'model':model,'messages':[{'role':'user','content':'Say ready.'}],'stream':False});r.raise_for_status()
with connect() as c:
    for key,value in [('mode','ollama'),('model',model),('embedding_model',embedding)]:c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(key,json.dumps(value)))
print('Local inference smoke checks passed. AI mode enabled. Run the evaluation suite next.')
