"""Start a synthetic-only public preview; credentials are read only from host secrets."""
import os,sys,subprocess,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
password=os.getenv('KP_BOOTSTRAP_PASSWORD','')
if len(password)<12:raise SystemExit('Configure KP_BOOTSTRAP_PASSWORD in hosting secrets (minimum 12 characters).')
mode=os.getenv('KP_ANSWER_MODE','hosted')
if mode=='hosted' and not os.getenv('KP_LLM_API_KEY'):raise SystemExit('Configure KP_LLM_API_KEY in hosting secrets before deploying hosted AI.')
os.environ.setdefault('KP_DATA_DIR','/tmp/knowledgepilot-demo')
subprocess.run([sys.executable,'scripts/bootstrap.py'],check=True)
sys.path.insert(0,str(ROOT))
from backend.db import connect
with connect() as c:
    for key,value in [('mode',mode),('model',os.getenv('KP_LLM_MODEL','openai/gpt-oss-20b')),('top_k',4),('reranker','none')]:c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(key,json.dumps(value)))
os.execv(sys.executable,[sys.executable,'-m','uvicorn','backend.api:app','--host',os.getenv('HOST','0.0.0.0'),'--port',os.getenv('PORT','8000'),'--workers','1'])
