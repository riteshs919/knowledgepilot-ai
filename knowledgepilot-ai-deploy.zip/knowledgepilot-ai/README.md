# KnowledgePilot AI

An independent portfolio application for Ritesh Singh, imported from the supplied project ZIP. All Northstar Cloud documents are synthetic. No employer code or client records are included.

## What works
Authenticated knowledge workspace, PDF/DOCX/Markdown/TXT ingestion, SQLite storage, role/group/document permissions, keyword and vector retrieval, source citations, history, feedback and admin settings. Local Qwen 2.5 7B plus nomic embeddings has been exercised. A hosted compatible-API adapter supports the low-cost public preview.

## Free public-demo deployment
Use GitHub for source and Render Free for the Python app. The render.yaml blueprint defines the service. Generation uses Groq's free API tier with openai/gpt-oss-20b, subject to its current quotas. Hosted retrieval uses the lightweight latent-semantic vector provider, avoiding a large local embedding model on the free instance. The hosted adapter has mock tests; an actual hosted-key smoke test is required before calling the deployment verified.

1. Publish this sanitized folder as a GitHub repository.
2. Connect the repository to Render as a Blueprint. Keep plan: free.
3. Configure KP_LLM_API_KEY in Render's secret settings. Never commit it or paste it into a public issue. The generated bootstrap password is also a host secret.
4. Deploy and verify /api/health shows hosted mode, then use “Try the synthetic workspace” and ask a policy question.
5. Check citation links, unsupported refusal and admin denial. Record the actual public URL only after the build and live tests pass.

Render Free sleeps after inactivity and its filesystem is ephemeral. Synthetic data is bootstrapped after restarts; demo accounts/history/uploads may reset. Public demo sessions are employee-only, origin-checked and allowed only for the synthetic corpus. Chat budget is limited to two requests/minute across the preview to protect the free model quota. This is a portfolio demo, not production client hosting.

## Local mode
Install requirements-dev.txt in a virtual environment, set KP_BOOTSTRAP_PASSWORD and KP_DATA_DIR, run scripts/bootstrap.py, start Ollama with qwen2.5:7b and nomic-embed-text, then run scripts/configure_ai.py and uvicorn backend.api:app --host 127.0.0.1 --port 8000. Local API keys are not required. Do not use the hosted cloud_boot entrypoint for this path.

## Verification
Run pytest -q tests on a bootstrapped isolated synthetic database. A recorded 91-question local evaluation is in docs/technical/evaluation-results.json, with model, coverage and limitations. Citation-ID validity does not prove generated-answer truth. Hosting-provider behavior and hosted-model generation remain unverified until an actual deployment is performed.

## Boundaries
No OCR, SSO or multi-tenancy. API keys stay on the server. Do not upload real private data to this public demonstration. The repository intentionally excludes local credentials, model binaries, SQLite databases and resume evidence. MIT license from the supplied application is preserved.
