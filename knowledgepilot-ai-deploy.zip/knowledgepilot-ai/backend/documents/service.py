import hashlib,json,time,uuid,threading
from concurrent.futures import ThreadPoolExecutor
from fastapi import HTTPException
from backend.db import connect,settings,audit
from backend.ingestion.parser import extract,chunk
from backend.auth.security import allowed
pool=ThreadPoolExecutor(max_workers=2,thread_name_prefix='index')
slots=threading.BoundedSemaphore(16)
def index_document(doc_id):
    try:
        with connect() as c:
            d=c.execute('SELECT * FROM documents WHERE id=?',(doc_id,)).fetchone()
            if not d:return
            c.execute("UPDATE documents SET status='indexing' WHERE id=?",(doc_id,))
        config=settings(); pieces=chunk(extract(d['filename'],d['content']),config['chunk_size'],config['chunk_overlap'])
        with connect() as c:
            if not c.execute('SELECT 1 FROM documents WHERE id=?',(doc_id,)).fetchone():return
            c.execute('DELETE FROM chunks WHERE doc_id=?',(doc_id,))
            c.executemany('INSERT INTO chunks VALUES(?,?,?,?,?)',[(uuid.uuid4().hex,doc_id,p['page'],p['heading'],p['text']) for p in pieces])
            c.execute("UPDATE documents SET status='indexed',error=NULL WHERE id=?",(doc_id,))
    except Exception as e:
        with connect() as c:c.execute("UPDATE documents SET status='failed',error=? WHERE id=?",(str(e) if isinstance(e,ValueError) else 'Indexing failed. Check server health.',doc_id))
    finally:slots.release()
def enqueue(doc_id):
    if not slots.acquire(blocking=False):raise HTTPException(503,'Indexing queue is full. Try again shortly.')
    pool.submit(index_document,doc_id)
def upload(filename,data,meta,user,replace=None):
    if user['role'] not in ('admin','editor'):raise HTTPException(403,'Document editor access required.')
    from pathlib import Path
    from backend.ingestion.parser import SUPPORTED,MAX_BYTES
    if Path(filename).suffix.lower() not in SUPPORTED or not data or len(data)>MAX_BYTES:raise HTTPException(400,'Upload a nonempty PDF, DOCX, TXT or Markdown file up to 10 MiB.')
    family=uuid.uuid4().hex;version=1
    groups=meta.get('groups',['employees']);users=meta.get('users',[])
    if not isinstance(groups,list) or not isinstance(users,list) or any(not isinstance(x,str) or len(x)>80 for x in groups+users):raise HTTPException(422,'Invalid access rules.')
    if user['role']!='admin' and (not set(groups)<=set(user['groups']) or users):raise HTTPException(403,'Editors may assign their own groups only.')
    digest=hashlib.sha256(data).hexdigest()
    with connect() as c:
        if replace:
            old=c.execute('SELECT * FROM documents WHERE id=?',(replace,)).fetchone()
            if not old or not allowed(old,user):raise HTTPException(404,'Document not found.')
            family=old['family'];version=c.execute('SELECT MAX(version) FROM documents WHERE family=?',(family,)).fetchone()[0]+1
            # Replacements preserve ACL unless explicitly assigned by authorized editor.
            groups=meta.get('groups',json.loads(old['groups_json']));users=meta.get('users',json.loads(old['users_json']))
        duplicate=c.execute('SELECT * FROM documents WHERE hash=? AND family!=?',(digest,family)).fetchall()
        if any(allowed(x,user) for x in duplicate):raise HTTPException(409,'This document content is already uploaded.')
        doc_id=uuid.uuid4().hex
        c.execute('INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(doc_id,family,str(meta.get('title') or Path(filename).stem)[:160],Path(filename).name[:160],str(meta.get('category','General'))[:80],user['name'],version,str(meta.get('effective',''))[:30],json.dumps(groups),json.dumps(users),digest,'queued',None,data,time.time()))
    try:enqueue(doc_id)
    except HTTPException:
        with connect() as c:c.execute("UPDATE documents SET status='failed',error='Queue full; retry indexing.' WHERE id=?",(doc_id,))
        raise
    audit('document.upload',user['id'],doc_id)
    return doc_id

def list_documents(user):
    with connect() as c:
        rows=[dict(r) for r in c.execute('SELECT * FROM documents ORDER BY created DESC')]
    latest={}
    for r in rows:latest[r['family']]=max(latest.get(r['family'],0),r['version'])
    result=[]
    for d in rows:
        if allowed(d,user):
            d.pop('content');d['groups']=json.loads(d.pop('groups_json'));d['users']=json.loads(d.pop('users_json'));d['current']=d['version']==latest[d['family']];result.append(d)
    return result
