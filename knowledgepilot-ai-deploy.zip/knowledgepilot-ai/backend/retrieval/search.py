import json,re,threading,numpy as np
from typing import Protocol
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from backend.db import connect,settings
from backend.auth.security import allowed
from backend.retrieval.providers import LatentSemanticEmbedding,OllamaEmbedding,CrossEncoderReranker
class SearchBackend(Protocol):
    def search(self,query:str,user:dict,category:str='',top_k:int|None=None)->list[dict]: ...
class HybridSearch:
    def __init__(self): self.lock=threading.RLock();self.signature=None;self.reranker=None
    def search(self,query,user,category='',top_k=None):
        config=settings()
        with self.lock:
            with connect() as c:
                docs=[dict(x) for x in c.execute("SELECT * FROM documents WHERE status='indexed'")]
                # Current version is global per family; revoked or failed replacements fail closed.
                latest={r['family']:r['v'] for r in c.execute('SELECT family,MAX(version) v FROM documents GROUP BY family')}
                permitted={d['id']:d for d in docs if allowed(d,user) and d['version']==latest[d['family']] and (not category or d['category']==category)}
                rows=[dict(x) for x in c.execute('SELECT * FROM chunks') if x['doc_id'] in permitted]
            # Named policies narrow only the already-authorized candidates.
            named={d['id'] for d in permitted.values() if len(d['title'].split())>=2 and d['title'].lower() in query.lower()}
            remainder=query.lower()
            for doc_id in named:remainder=remainder.replace(permitted[doc_id]['title'].lower(),'')
            if len(named)==1 and any(word in remainder for word in (' and ',' compare ',' versus ',' vs ')):named=set()
            if named:rows=[r for r in rows if r['doc_id'] in named]
            if not rows:return []
            # Separate indexes per ACL result set: forbidden text cannot influence vectors or candidates.
            sig=(tuple(r['id'] for r in rows),config['mode'],config['embedding_model'])
            if sig!=self.signature:
                self.embed=OllamaEmbedding(config['embedding_model']) if config['mode']=='ollama' else LatentSemanticEmbedding()
                texts=[permitted[r['doc_id']]['title']+' '+r['heading']+' '+r['text'] for r in rows]
                self.vectors=self.embed.fit(texts);self.matrix=self.embed.vectorizer.transform(texts) if hasattr(self.embed,'vectorizer') else None
                self.signature=sig
            semantic=self.vectors@self.embed.query(query)
            if self.matrix is not None: keyword=(self.matrix@self.embed.vectorizer.transform([query]).T).toarray().ravel()
            else:
                terms=set(re.findall(r'\w+',query.lower()))-set(ENGLISH_STOP_WORDS)
                keyword=np.array([sum(t in r['text'].lower() for t in terms) for r in rows],float)
            terms=set(re.findall(r'\w+',query.lower()))-set(ENGLISH_STOP_WORDS)-{'does','say','policy','please','northstar','cloud','tell','currently','current','allowed','provide','provided','receive','receives'}
            # Unknown concepts cannot be safely answered from an unrelated passage.
            corpus_terms=set(re.findall(r'\w+', ' '.join(r['text']+' '+permitted[r['doc_id']]['title'] for r in rows).lower()))
            unknown=terms-corpus_terms
            anchored=any(len(d['title'].split())>=2 and d['title'].lower() in query.lower() for d in permitted.values())
            if not anchored and len(unknown)>=2 and len(unknown)/max(1,len(terms))>.3:return []
            fused={}
            for scores in (keyword,semantic):
                for rank,i in enumerate(np.argsort(-scores)[:30]):
                    if scores[i]>0.015:fused[int(i)]=fused.get(int(i),0)+1/(60+rank+1)
            results=[]
            for i,score in sorted(fused.items(),key=lambda x:-x[1]):
                row=rows[i];doc=permitted[row['doc_id']]
                overlap=terms & set(re.findall(r'\w+',(doc['title']+' '+row['heading']+' '+row['text']).lower()))
                # Conservative evidence gate avoids unsupported semantic-only extrapolation.
                if not terms or len(overlap)<min(2,len(terms)):continue
                results.append({**row,'title':doc['title'],'version':doc['version'],'category':doc['category'],'score':score,'semantic_score':float(semantic[i]),'keyword_score':float(keyword[i])})
            def heading_priority(result):
                heading=result['heading'].lower();q=query.lower()
                if 'operating requirements' in q and 'operating requirements' in heading:return 2
                if ('approv' in q or 'exception' in q) and 'approval requirements' in heading:return 2
                if 'exception' in q and 'exceptions' in heading:return 1
                return 0
            if named:results.sort(key=lambda r:(heading_priority(r),r['score']),reverse=True)
            if config['reranker']=='cross-encoder' and results:
                if self.reranker is None:self.reranker=CrossEncoderReranker()
                results=self.reranker.rank(query,results[:20])
            return results[:top_k or config['top_k']]
search=HybridSearch()
