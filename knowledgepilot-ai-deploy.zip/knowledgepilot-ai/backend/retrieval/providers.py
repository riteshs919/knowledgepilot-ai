"""Pluggable local providers; latent semantic mode requires no downloaded weights."""
from typing import Protocol
import os,httpx,numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize
class EmbeddingProvider(Protocol):
    def fit(self,texts:list[str])->np.ndarray: ...
    def query(self,text:str)->np.ndarray: ...
class LatentSemanticEmbedding:
    def fit(self,texts):
        self.vectorizer=TfidfVectorizer(stop_words='english',sublinear_tf=True,ngram_range=(1,2),max_features=20000)
        x=self.vectorizer.fit_transform(texts)
        self.svd=None
        if min(x.shape)>10:
            self.svd=TruncatedSVD(n_components=min(128,min(x.shape)-1),random_state=42)
            return normalize(self.svd.fit_transform(x))
        return normalize(x.toarray())
    def query(self,text):
        x=self.vectorizer.transform([text])
        return normalize(self.svd.transform(x) if self.svd else x.toarray())[0]
class OllamaEmbedding:
    def __init__(self,model): self.model=model
    def _embed(self,texts):
        vectors=[]
        for i in range(0,len(texts),32):
            with httpx.Client(timeout=120,trust_env=False) as c:
                r=c.post(os.getenv('OLLAMA_URL','http://localhost:11434')+'/api/embed',json={'model':self.model,'input':texts[i:i+32]});r.raise_for_status();vectors+=r.json()['embeddings']
        return normalize(np.array(vectors))
    def fit(self,texts):
        prefix='search_document: ' if self.model.startswith('nomic-embed-text') else ''
        return self._embed([prefix+t for t in texts])
    def query(self,text):
        prefix='search_query: ' if self.model.startswith('nomic-embed-text') else ''
        return self._embed([prefix+text])[0]
class Reranker(Protocol):
    def rank(self,query:str,results:list[dict])->list[dict]: ...
class CrossEncoderReranker:
    def __init__(self):
        from sentence_transformers import CrossEncoder
        self.model=CrossEncoder(os.getenv('KP_RERANK_MODEL','cross-encoder/ms-marco-MiniLM-L6-v2'),local_files_only=True)
    def rank(self,query,results):
        scores=self.model.predict([(query,r['text']) for r in results])
        return [r for _,r in sorted(zip(scores,results),key=lambda x:float(x[0]),reverse=True)]
