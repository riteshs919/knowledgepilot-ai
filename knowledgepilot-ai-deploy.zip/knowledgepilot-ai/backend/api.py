import os,time,json,uuid,hashlib,secrets,logging,threading,smtplib
from collections import defaultdict,deque
from pathlib import Path
from email.message import EmailMessage
from contextlib import asynccontextmanager
from fastapi import FastAPI,Request,Response,Depends,HTTPException,UploadFile,File,Form
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel,Field,field_validator
from backend.db import connect,init,settings,audit
from backend.auth.security import current_user,admin,allowed,verify_password,hash_password,COOKIE
from backend.documents.service import upload,list_documents,enqueue
from backend.retrieval.search import search
from backend.generation.engine import answer
ROOT=Path(__file__).resolve().parents[1]
log=logging.getLogger('knowledgepilot')
logging.basicConfig(level=logging.INFO,format='%(message)s')
@asynccontextmanager
async def lifespan(app):
    init()
    with connect() as c:
        interrupted=[x['id'] for x in c.execute("SELECT id FROM documents WHERE status IN ('queued','indexing')")]
    for doc in interrupted:
        try:enqueue(doc)
        except HTTPException:break
    yield
app=FastAPI(title='KnowledgePilot AI',lifespan=lifespan)
limits=defaultdict(deque);limit_lock=threading.Lock();query_slots=threading.BoundedSemaphore(4)
@app.middleware('http')
async def safeguards(request,call_next):
    started=time.perf_counter();ip=request.client.host if request.client else 'unknown';path=request.url.path
    length=request.headers.get('content-length','0')
    try:
        if int(length)>11*1024*1024:return Response('Request exceeds the 11 MiB body limit.',status_code=413)
    except ValueError:return Response('Invalid content length.',status_code=400)
    if request.method=='POST':
        key=(ip,'login' if path.endswith('/login') else 'contact' if path.endswith('/contact') else 'write')
        maximum=int(os.getenv('KP_CHAT_RPM','90')) if path=='/api/chat' else 10 if key[1] in ('login','contact') else 90
        if path=='/api/chat':key=('all-demo-users','chat-budget')
        with limit_lock:
            q=limits[key];now=time.monotonic()
            while q and q[0]<now-60:q.popleft()
            if len(q)>=maximum:return Response('Too many requests. Retry in a minute.',status_code=429)
            q.append(now)
            if len(limits)>10000:
                for k in list(limits):
                    if not limits[k] or limits[k][-1]<now-60:del limits[k]
    try:r=await call_next(request)
    except Exception:
        log.error(json.dumps({'event':'request.failed','path':path}))
        r=Response('An internal error occurred. Check system health.',status_code=500)
    r.headers['X-Content-Type-Options']='nosniff';r.headers['X-Frame-Options']='DENY';r.headers['Referrer-Policy']='same-origin'
    r.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    r.headers['Cache-Control']='no-store' if path.startswith('/api') else 'no-cache'
    log.info(json.dumps({'event':'http','method':request.method,'path':path,'status':r.status_code,'ms':round((time.perf_counter()-started)*1000,2)}))
    return r
class Login(BaseModel):
    email:str=Field(max_length=254)
    password:str=Field(min_length=1,max_length=128)
@app.post('/api/auth/login')
def login(body:Login,response:Response):
    with connect() as c:row=c.execute('SELECT * FROM users WHERE email=? AND active=1',(body.email.lower(),)).fetchone()
    # Equalize expensive hash work for nonexistent accounts.
    valid=verify_password(body.password,row['password'] if row else '0'*32+':'+'0'*128)
    if not row or not valid:raise HTTPException(401,'Email or password is incorrect.')
    token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24)
    with connect() as c:
        c.execute('DELETE FROM sessions WHERE expires<?',(time.time(),))
        c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),row['id'],csrf,time.time()+8*3600))
    response.set_cookie(COOKIE,token,httponly=True,secure=os.getenv('KP_SECURE_COOKIES','false')=='true',samesite='strict',max_age=8*3600)
    audit('auth.login',row['id']);return {'ok':True}
@app.post('/api/auth/demo')
def demo_session(request:Request,response:Response):
    # Explicit opt-in for the supplied synthetic corpus. No administrator privileges.
    if os.getenv('KP_ENABLE_PUBLIC_DEMO')!='true':raise HTTPException(404,'Demo access is disabled.')
    from urllib.parse import urlparse
    public=os.getenv('KP_PUBLIC_ORIGIN') or os.getenv('RENDER_EXTERNAL_URL','')
    origins={'http://localhost:3000','http://127.0.0.1:3000','http://localhost:8000','http://127.0.0.1:8000'}
    if public:origins.add(public.rstrip('/'))
    if request.headers.get('origin','').rstrip('/') not in origins:raise HTTPException(403,'Demo origin is not allowed.')
    with connect() as c:
        ids=[r['id'] for r in c.execute('SELECT id FROM documents')]
        if not ids or any(not x.startswith('NS-') for x in ids):raise HTTPException(403,'Demo access requires the original synthetic corpus.')
        uid=uuid.uuid4().hex;token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24)
        c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,1)',(uid,'visitor-'+uid+'@northstar.demo','Demo Visitor',hash_password(secrets.token_urlsafe(32)),'employee','["employees"]'))
        c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),uid,csrf,time.time()+3600))
    response.set_cookie(COOKIE,token,httponly=True,secure=os.getenv('KP_SECURE_COOKIES','false')=='true',samesite='strict',max_age=3600)
    return {'ok':True}
@app.get('/api/auth/me')
def me(user=Depends(current_user)):return user
@app.post('/api/auth/logout')
def logout(request:Request,response:Response,user=Depends(current_user)):
    with connect() as c:c.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(request.cookies.get(COOKIE,'').encode()).hexdigest(),))
    response.delete_cookie(COOKIE);return {'ok':True}
@app.get('/api/health')
def health():
    with connect() as c:c.execute('SELECT 1')
    return {'status':'ok','mode':settings()['mode'],'database':'ok','public_demo':os.getenv('KP_ENABLE_PUBLIC_DEMO')=='true','ephemeral_demo':os.getenv('KP_EPHEMERAL_DEMO')=='true'}
@app.get('/api/documents')
def documents(user=Depends(current_user)):return list_documents(user)
@app.post('/api/documents',status_code=202)
def create_document(file:UploadFile=File(...),metadata:str=Form('{}'),replace:str=Form(''),user=Depends(current_user)):
    data=file.file.read(10*1024*1024+1)
    try:meta=json.loads(metadata)
    except Exception:raise HTTPException(422,'Invalid document metadata.')
    if not isinstance(meta,dict):raise HTTPException(422,'Invalid document metadata.')
    return {'id':upload(file.filename or '',data,meta,user,replace or None),'status':'queued'}
def accessible_document(doc_id,user):
    with connect() as c:d=c.execute('SELECT * FROM documents WHERE id=?',(doc_id,)).fetchone()
    if not d or not allowed(d,user):raise HTTPException(404,'Document not found.')
    return d
@app.get('/api/documents/{doc_id}')
def preview(doc_id:str,user=Depends(current_user)):
    d=accessible_document(doc_id,user)
    with connect() as c:pieces=[dict(x) for x in c.execute('SELECT page,heading,text FROM chunks WHERE doc_id=?',(doc_id,))]
    return {'id':doc_id,'title':d['title'],'status':d['status'],'error':d['error'],'passages':pieces}
@app.get('/api/documents/{doc_id}/download')
def download(doc_id:str,user=Depends(current_user)):
    d=accessible_document(doc_id,user)
    return Response(bytes(d['content']),media_type='application/octet-stream',headers={'Content-Disposition':"attachment; filename*=UTF-8''"+__import__('urllib.parse',fromlist=['quote']).quote(d['filename'])})
@app.delete('/api/documents/{doc_id}')
def delete(doc_id:str,user=Depends(current_user)):
    admin(user);accessible_document(doc_id,user)
    with connect() as c:
        # Delete the complete version family so an old policy cannot become current.
        family=c.execute('SELECT family FROM documents WHERE id=?',(doc_id,)).fetchone()[0]
        c.execute('DELETE FROM documents WHERE family=?',(family,))
    audit('document.delete_family',user['id'],doc_id);return {'ok':True}
@app.post('/api/documents/{doc_id}/retry')
def retry(doc_id:str,user=Depends(current_user)):
    admin(user);accessible_document(doc_id,user);enqueue(doc_id);return {'ok':True}
class Question(BaseModel):
    question:str=Field(min_length=3,max_length=2000)
    conversation_id:str|None=None
    category:str=Field(default='',max_length=80)
@app.post('/api/search')
def retrieve(body:Question,user=Depends(current_user)):
    try:return {'sources':search.search(body.question,user,body.category)}
    except (httpx.HTTPError,ImportError,OSError):raise HTTPException(503,'Local embedding or reranking provider unavailable.')
import httpx
@app.post('/api/chat')
def chat(body:Question,user=Depends(current_user)):
    if not query_slots.acquire(blocking=False):raise HTTPException(503,'Assistant is busy. Try again shortly.')
    start=time.perf_counter()
    try:
        conversation=body.conversation_id or uuid.uuid4().hex
        with connect() as c:
            if body.conversation_id:
                if not c.execute('SELECT 1 FROM conversations WHERE id=? AND user_id=?',(conversation,user['id'])).fetchone():raise HTTPException(404,'Conversation not found.')
            else:c.execute('INSERT INTO conversations VALUES(?,?,?,?)',(conversation,user['id'],body.question[:80],time.time()))
            prior=c.execute("SELECT body FROM messages WHERE conversation_id=? AND role='user' ORDER BY created DESC LIMIT 1",(conversation,)).fetchone()
        q=body.question
        if prior and (len(q.split())<7 or any(x in q.lower().split() for x in ('it','that','those','they'))):q=prior['body']+'\nFollow-up: '+q
        sources=search.search(q,user,body.category)
        result,sources,supported=answer(q,sources,settings())
        query_id=uuid.uuid4().hex;latency=time.perf_counter()-start
        with connect() as c:
            c.execute('INSERT INTO queries VALUES(?,?,?,?,?,?)',(query_id,user['id'],latency,len(sources),int(supported),time.time()))
            c.execute('INSERT INTO messages VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,conversation,'user',body.question,'[]',time.time()))
            c.execute('INSERT INTO messages VALUES(?,?,?,?,?,?)',(query_id,conversation,'assistant',result,json.dumps(sources),time.time()))
        return {'id':query_id,'conversation_id':conversation,'answer':result,'sources':sources,'supported':supported,'latency':latency,'mode':settings()['mode']}
    except (httpx.HTTPError,ImportError,OSError):raise HTTPException(503,'The configured AI provider is unavailable. Please try again later; no simulated answer was used.')
    finally:query_slots.release()
@app.get('/api/conversations')
def conversations(user=Depends(current_user)):
    with connect() as c:return [dict(x) for x in c.execute('SELECT * FROM conversations WHERE user_id=? ORDER BY created DESC',(user['id'],))]
@app.get('/api/conversations/{conversation_id}')
def history(conversation_id:str,user=Depends(current_user)):
    with connect() as c:
        if not c.execute('SELECT 1 FROM conversations WHERE id=? AND user_id=?',(conversation_id,user['id'])).fetchone():raise HTTPException(404,'Conversation not found.')
        messages=[dict(x) for x in c.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY created',(conversation_id,))]
        for m in messages:
            # Revalidate history citations after ACL changes and document deletion.
            sources=json.loads(m['sources']);permitted=[]
            for s in sources:
                d=c.execute('SELECT * FROM documents WHERE id=?',(s['doc_id'],)).fetchone()
                if d and allowed(d,user):permitted.append(s)
            if m['role']=='assistant' and len(permitted)!=len(sources):m['body']='This answer is unavailable because source access has changed.';permitted=[]
            m['sources']=permitted
        return messages
class Rating(BaseModel):
    rating:int
@app.post('/api/feedback/{query_id}')
def feedback(query_id:str,body:Rating,user=Depends(current_user)):
    if body.rating not in (-1,1):raise HTTPException(422,'Rating must be -1 or 1.')
    with connect() as c:
        if not c.execute('SELECT 1 FROM queries WHERE id=? AND user_id=?',(query_id,user['id'])).fetchone():raise HTTPException(404,'Answer not found.')
        c.execute('INSERT OR REPLACE INTO feedback VALUES(?,?,?)',(query_id,user['id'],body.rating))
    return {'ok':True}
@app.get('/api/admin/metrics')
def metrics(user=Depends(current_user)):
    admin(user)
    with connect() as c:
        counts={x['status']:x['n'] for x in c.execute('SELECT status,COUNT(*) n FROM documents GROUP BY status')}
        usage=dict(c.execute('SELECT COUNT(*) queries,AVG(latency) avg_latency,SUM(supported) supported FROM queries').fetchone())
        ratings=[dict(x) for x in c.execute('SELECT rating,COUNT(*) count FROM feedback GROUP BY rating')]
        users=c.execute('SELECT COUNT(*) FROM users WHERE active=1').fetchone()[0]
        events=[dict(x) for x in c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 30')]
    report=ROOT/'docs/technical/evaluation-results.json'
    return {'documents':counts,'total_documents':sum(counts.values()),'active_accounts':users,'usage':usage,'feedback':ratings,'audit':events,'evaluation':json.loads(report.read_text()) if report.exists() else None,'health':health()}
@app.get('/api/settings')
def get_settings(user=Depends(current_user)):return settings()
class Config(BaseModel):
    mode:str
    model:str=Field(min_length=1,max_length=100)
    embedding_model:str=Field(min_length=1,max_length=100)
    top_k:int=Field(ge=1,le=12)
    chunk_size:int=Field(ge=80,le=800)
    chunk_overlap:int=Field(ge=0,le=200)
    reranker:str
    @field_validator('mode')
    @classmethod
    def mode_valid(cls,v):
        if v not in ('extractive','ollama','hosted'):raise ValueError('Invalid mode')
        return v
    @field_validator('reranker')
    @classmethod
    def rerank_valid(cls,v):
        if v not in ('none','cross-encoder'):raise ValueError('Invalid reranker')
        return v
@app.put('/api/settings')
def config(body:Config,user=Depends(current_user)):
    admin(user)
    if body.chunk_overlap>=body.chunk_size//2:raise HTTPException(422,'Overlap must be less than half the chunk size.')
    with connect() as c:
        for k,v in body.model_dump().items():c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(k,json.dumps(v)))
    audit('settings.update',user['id']);return {'ok':True,'note':'Chunk settings apply to new uploads or explicit retry indexing.'}
@app.get('/api/admin/users')
def users(user=Depends(current_user)):
    admin(user)
    with connect() as c:return [dict(x) for x in c.execute('SELECT id,email,name,role,groups_json,active FROM users')]
class UserInput(BaseModel):
    email:str=Field(min_length=5,max_length=254)
    name:str=Field(min_length=2,max_length=80)
    password:str=Field(min_length=12,max_length=128)
    role:str
    groups:list[str]=Field(max_length=20)
@app.post('/api/admin/users')
def create_user(body:UserInput,user=Depends(current_user)):
    admin(user)
    if body.role not in ('admin','editor','employee') or '@' not in body.email or any(len(g)>80 for g in body.groups):raise HTTPException(422,'Invalid user details.')
    try:
        with connect() as c:c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,1)',(uuid.uuid4().hex,body.email.lower(),body.name,hash_password(body.password),body.role,json.dumps(body.groups)))
    except __import__('sqlite3').IntegrityError:raise HTTPException(409,'Account already exists.')
    audit('user.create',user['id']);return {'ok':True}
@app.delete('/api/admin/users/{user_id}')
def disable_user(user_id:str,user=Depends(current_user)):
    admin(user)
    if user_id==user['id']:raise HTTPException(400,'You cannot disable your own account.')
    with connect() as c:c.execute('UPDATE users SET active=0 WHERE id=?',(user_id,));c.execute('DELETE FROM sessions WHERE user_id=?',(user_id,))
    audit('user.disable',user['id'],user_id);return {'ok':True}
class Lead(BaseModel):
    name:str=Field(min_length=2,max_length=100)
    email:str=Field(min_length=5,max_length=254)
    company:str=Field(min_length=2,max_length=100)
    country:str=Field(min_length=2,max_length=80)
    requirements:str=Field(min_length=20,max_length=4000)
    budget:str=Field(min_length=1,max_length=100)
    timeline:str=Field(min_length=1,max_length=100)
    website:str=Field(default='',max_length=200)
    @field_validator('email')
    @classmethod
    def email_valid(cls,v):
        import re
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',v):raise ValueError('Invalid email')
        return v
@app.post('/api/contact')
def contact(body:Lead):
    if body.website:raise HTTPException(400,'Submission rejected.')
    destination=os.getenv('KP_LEAD_EMAIL');host=os.getenv('KP_SMTP_HOST')
    if not destination or not host:raise HTTPException(503,'Contact delivery is not configured. Please use LinkedIn to contact Ritesh.')
    message=EmailMessage();message['Subject']='KnowledgePilot pilot inquiry';message['From']=os.getenv('KP_SMTP_FROM',destination);message['To']=destination;message['Reply-To']=body.email;message.set_content(json.dumps(body.model_dump(exclude={'website'}),indent=2))
    try:
        with smtplib.SMTP(host,int(os.getenv('KP_SMTP_PORT','587')),timeout=15) as s:
            s.starttls()
            if os.getenv('KP_SMTP_USER'):s.login(os.environ['KP_SMTP_USER'],os.environ['KP_SMTP_PASSWORD'])
            rejected=s.send_message(message)
            if rejected:raise RuntimeError('Recipient rejected')
    except Exception:raise HTTPException(502,'Delivery failed. Please retry or contact Ritesh on LinkedIn.')
    # No persistent personal lead data by default. SMTP acceptance is the success boundary.
    return {'ok':True,'message':'Your inquiry was accepted by the configured mail server.'}
app.mount('/assets',StaticFiles(directory=ROOT/'apps/web'),name='assets')
app.mount('/portfolio-assets',StaticFiles(directory=ROOT/'apps/portfolio'),name='portfolio-assets')
@app.get('/portfolio')
@app.get('/portfolio/{page}')
def portfolio(page:str='home'):return FileResponse(ROOT/'apps/portfolio/index.html')
@app.get('/')
def index():return FileResponse(ROOT/'apps/web/index.html')
