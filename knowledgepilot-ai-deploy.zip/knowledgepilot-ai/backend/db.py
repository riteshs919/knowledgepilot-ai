"""SQLite repository. Connections are short lived; all mutations use transactions."""
import os, sqlite3, json
from pathlib import Path
DATA = Path(os.getenv('KP_DATA_DIR', 'data'))
DATA.mkdir(parents=True, exist_ok=True)
DB = DATA / 'knowledgepilot.db'
def connect():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA journal_mode=WAL')
    return c

def init():
    with connect() as c:
        c.executescript((Path(__file__).parent/'migrations/001_initial.sql').read_text())
        defaults={'mode':'extractive','model':'qwen2.5:1.5b','embedding_model':'nomic-embed-text','top_k':6,'chunk_size':220,'chunk_overlap':30,'reranker':'none'}
        for k,v in defaults.items(): c.execute('INSERT OR IGNORE INTO settings VALUES(?,?)',(k,json.dumps(v)))
def settings():
    with connect() as c: return {r['key']:json.loads(r['value']) for r in c.execute('SELECT * FROM settings')}
def audit(event,user,target=''):
    import time
    with connect() as c: c.execute('INSERT INTO audit(event,user_id,target,created) VALUES(?,?,?,?)',(event,user,target,time.time()))
