"""Deterministic metrics; no human quality judgement implied."""
def recall_at_k(expected,retrieved):
    return len(set(expected)&set(retrieved))/len(set(expected)) if expected else None

def citation_validity(answer,sources):
    from backend.generation.engine import validate_citations
    return validate_citations(answer,sources)

def extractive_support(answer,sources):
    return bool(sources) and all(s['text'] in answer for s in sources)
