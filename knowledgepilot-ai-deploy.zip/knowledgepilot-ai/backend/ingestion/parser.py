"""Bounded in-process parsers. PDF text layer only: no OCR."""
import io,zipfile,re
from pypdf import PdfReader
from docx import Document
SUPPORTED={'.pdf','.docx','.txt','.md'}
MAX_BYTES=10*1024*1024

def extract(filename,data):
    from pathlib import Path
    ext=Path(filename).suffix.lower()
    if ext not in SUPPORTED: raise ValueError('Supported formats: PDF, DOCX, TXT, Markdown.')
    if not data or len(data)>MAX_BYTES: raise ValueError('File must be nonempty and at most 10 MiB.')
    try:
        if ext=='.pdf':
            if not data.startswith(b'%PDF-'): raise ValueError('Invalid PDF signature.')
            reader=PdfReader(io.BytesIO(data))
            if reader.is_encrypted: raise ValueError('Encrypted PDFs are not supported.')
            if len(reader.pages)>500: raise ValueError('PDF exceeds 500 pages.')
            pages=[(i+1,p.extract_text(extraction_mode='layout') or '') for i,p in enumerate(reader.pages)]
        elif ext=='.docx':
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                if sum(x.file_size for x in z.infolist())>50*1024*1024 or len(z.infolist())>2000: raise ValueError('DOCX expands beyond safe limits.')
                if 'word/document.xml' not in z.namelist(): raise ValueError('Invalid DOCX structure.')
            d=Document(io.BytesIO(data))
            lines=[('# ' if p.style.name.startswith('Heading') else '')+p.text for p in d.paragraphs]
            lines += [' | '.join(cell.text for cell in row.cells) for t in d.tables for row in t.rows]
            pages=[(None,'\n'.join(lines))]
        else:
            if b'\x00' in data: raise ValueError('Binary content is not allowed in text documents.')
            pages=[(None,data.decode('utf-8-sig'))]
        if not any(t.strip() for _,t in pages): raise ValueError('No text found. Scanned PDFs require external OCR; OCR is not implemented.')
        if sum(len(t) for _,t in pages)>2_000_000: raise ValueError('Extracted text exceeds safe limits.')
        return pages
    except ValueError: raise
    except Exception as e: raise ValueError('Corrupted or unsupported document content.') from e

def chunk(pages,size=220,overlap=30):
    if not 80<=size<=800 or not 0<=overlap<size//2: raise ValueError('Invalid chunk settings.')
    result=[]
    for page,text in pages:
        heading='Document';buffer=[]
        def flush():
            nonlocal buffer
            while buffer:
                result.append({'page':page,'heading':heading,'text':' '.join(buffer[:size])})
                if len(buffer)<=size: break
                buffer=buffer[size-overlap:]
            buffer=[]
        for line in text.splitlines():
            if re.match(r'^#{1,6}\s',line) or (line.isupper() and 4<len(line)<100):
                flush(); heading=line.lstrip('# ').strip()
            else: buffer.extend(line.split())
        flush()
    return [x for x in result if x['text'].strip()]
