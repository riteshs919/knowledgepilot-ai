import hashlib,hmac,secrets,time,json
from fastapi import HTTPException,Request
from backend.db import connect
COOKIE='kp_session'
def hash_password(password):
    salt=secrets.token_hex(16)
    return salt+':'+hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()
def verify_password(password,stored):
    salt,digest=stored.split(':')
    return hmac.compare_digest(hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex(),digest)
def current_user(request:Request):
    token=request.cookies.get(COOKIE,'')
    with connect() as c:
        row=c.execute('SELECT u.*,s.csrf FROM users u JOIN sessions s ON u.id=s.user_id WHERE s.token=? AND s.expires>? AND u.active=1',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
    if not row: raise HTTPException(401,'Please sign in.')
    user=dict(row);user['groups']=json.loads(user.pop('groups_json'));user.pop('password')
    if request.method not in ('GET','HEAD','OPTIONS') and not hmac.compare_digest(request.headers.get('x-csrf-token',''),user['csrf']): raise HTTPException(403,'Invalid session verification. Refresh and retry.')
    return user

def admin(user):
    if user['role']!='admin': raise HTTPException(403,'Administrator access required.')
def allowed(doc,user):
    return user['role']=='admin' or bool(set(json.loads(doc['groups_json'])) & set(user['groups'])) or user['id'] in json.loads(doc['users_json'])
